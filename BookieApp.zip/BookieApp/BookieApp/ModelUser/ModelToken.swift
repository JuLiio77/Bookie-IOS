//
//  ModelToken.swift
//  BookieApp
//
//  Created by dam2 on 8/4/24.
//

import Foundation

struct ModelToken: Decodable{
    
    var token: String
}
