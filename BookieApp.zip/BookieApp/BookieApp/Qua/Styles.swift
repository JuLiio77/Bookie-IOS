//
//  Styles.swift
//  BookieApp
//
//  Created by dam2 on 1/4/24.
//

import Foundation


//extension Styles{
//    func primmaryTextField() -> some view {
//        self
//        .labelStyle(.titleOnly)
//        .padding(.top, 90)
//        .padding(.trailing, 280)
//    }
//}
