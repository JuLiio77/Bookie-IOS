//
//  Categorias.swift
//  BookieApp
//
//  Created by dam2 on 20/5/24.
//

import Foundation

struct Categorias: Identifiable {
    
    var id = UUID()
    var nombre: String
    var imagen: String
}
