//
//  ViewFotoPerfil.swift
//  BookieApp
//
//  Created by dam2 on 15/3/24.
//

import SwiftUI

struct ViewFotoPerfil: View {
    var body: some View {
        
        
        
        Circle()
            .foregroundStyle(.gray)
    }
}

#Preview {
    ViewFotoPerfil()
}
