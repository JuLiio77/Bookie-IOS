//
//  RespuestaApi.swift
//  BookieApp
//
//  Created by dam2 on 18/3/24.
//

import Foundation

struct RespuestaApi: Decodable{
    
    
    
    
}
