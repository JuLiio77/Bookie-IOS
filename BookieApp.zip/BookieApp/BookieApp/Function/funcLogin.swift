//
//  funcLogin.swift
//  BookieApp
//
//  Created by dam2 on 11/3/24.
//

import Foundation
