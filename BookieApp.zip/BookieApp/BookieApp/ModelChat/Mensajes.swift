//
//  Mensajes.swift
//  BookieApp
//
//  Created by dam2 on 4/4/24.
//

import Foundation

struct Mensajes{
    
    let id: Int
    var texto: String
    var usuario: ModelUser
    var chats: Chats
}
