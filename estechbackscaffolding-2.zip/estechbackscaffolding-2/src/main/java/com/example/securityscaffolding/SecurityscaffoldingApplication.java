package com.example.securityscaffolding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityscaffoldingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityscaffoldingApplication.class, args);
	}

}
