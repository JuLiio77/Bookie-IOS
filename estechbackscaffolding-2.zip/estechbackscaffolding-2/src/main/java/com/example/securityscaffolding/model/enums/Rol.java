package com.example.securityscaffolding.model.enums;

public enum Rol {
    ROLE_USER,ROLE_ADMIN
}
