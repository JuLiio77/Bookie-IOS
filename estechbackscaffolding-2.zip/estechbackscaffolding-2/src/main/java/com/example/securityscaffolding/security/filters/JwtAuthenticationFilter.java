package com.example.securityscaffolding.security.filters;

import com.example.securityscaffolding.security.service.JwtService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    public static  final Logger logger = LoggerFactory.getLogger(JwtAuthenticationFilter.class);

    // Este filtro verifica si se tiene el token o si no e tiene

    @Autowired
    private JwtService jwtService;
    @Autowired
    private  UserDetailsService userDetailsService;


    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request,
                                    @NonNull HttpServletResponse response,
                                    @NonNull FilterChain filterChain) throws ServletException, IOException {


        final String authHeader = request.getHeader("Authorization");
        final String jwt;
        final String userAuth;

        if(authHeader == null || !authHeader.startsWith("Bearer ")) {
            logger.info("No tienes el token correcto");
            filterChain.doFilter(request, response);
            return;
        }

        jwt = authHeader.substring(7); // contamos 7 caracteres en "Bearer "(incluye el espacio en blanco)
        userAuth = jwtService.extractUsername(jwt);

        logger.info("Este es el token jwt " + jwt);

        logger.info("Este es el usuario autenticado.." + userAuth);

        // Verifico si el usuario aún no está autenticado pero el proceso de validación del token ya se ha realizado
        if(userAuth != null && SecurityContextHolder.getContext().getAuthentication() == null){

            // Cargo al usuario autenticado
            UserDetails userDetails = this.userDetailsService.loadUserByUsername(userAuth);
            logger.info("EL usuario extraido del userDetailsService es " + userDetails.getUsername());

            // Verifico si el token es válido y si esto es cierto actualizo el contexto de seguridad
            if(jwtService.isTokenValid(jwt, userDetails)){

                logger.info("El token es válido");

                UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
                        userDetails,
                        null,
                        userDetails.getAuthorities()
                );
                // Setteo los detalles del usuario autenticado en la petición y actualizo el contexto de seguridad con estos detalles
                authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                SecurityContextHolder.getContext().setAuthentication(authToken);

            }
        }

        filterChain.doFilter(request,response);

    }
}
